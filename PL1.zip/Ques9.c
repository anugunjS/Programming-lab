#include <stdio.h>

typedef struct
{
    float m;
    float c;
}line;

int checkS(line l1,line l2);

int main()
{
    line l1,l2;

    printf("m1: ");
    scanf("%f",&l1.m);
    printf("c1: ");
    scanf("%f",&l1.c);

     printf("m1: ");
    scanf("%f",&l2.m);
    printf("c1: ");
    scanf("%f",&l2.c);

        switch (checkS(l1,l2))
        {
            case 0:
                printf("Parallel.\n");
                break;
            case 90:
                printf("Perpendicular\n");
                break;
            default:
                printf("Intersecting with an angle not equal to 90.\n");
        }
    return 0;
}

int checkS(line l1,line l2)
{
    if (l1.m == l2.m)
    {
      return 0;
    }
    else if (l1.m * l2.m == -1)
    {
       return 90;
    }
    else
    {
    return -1;
     }
}
