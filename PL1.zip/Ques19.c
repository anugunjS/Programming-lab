#include <stdio.h>
#include <string.h>
#include <ctype.h>

void strCompare(char *str1, char *str2);


int main() {
    char str1[100], str2[100];
    printf("String1: ");
    fgets(str1, sizeof(str1), stdin);

    printf("String2: ");
    fgets(str2, sizeof(str2), stdin);
    strCompare(str1,str2);
    return 0;
}

void strCompare(char *str1, char *str2)
{
    int i;
     for(i=0;i<strlen(str1);i++)
    {
        if(isupper(str1[i]))
           str1[i]=tolower(str1[i]);
    }
    for(i=0;i<strlen(str2);i++)
    {
      if(isupper(str2[i]))
        str2[i]=tolower(str2[i]);
    }
    int result = strcmp(str1, str2);

    if (result == 0)
    {
        printf("same\n");
    }
     else
     {
        printf("not same\n");
    }

}
