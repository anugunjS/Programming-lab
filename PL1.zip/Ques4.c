#include <stdio.h>

int sumDiv(int n);

int main() {
    int n1=0, n2=0;
    printf("Enter two integers: ");
    scanf("%d %d",&n1,&n2);
    
    if (sumDiv(n1) == n2 && sumDiv(n2) == n1) {
        printf("%d and %d are Amicable numbers.", n1, n2);
    } else {
        printf("%d and %d are not Amicable numbers.", n1, n2);
    }
    
    return 0;
}

int sumDiv(int n) {
    int i,sum=0;
    for ( i = 1; i <= n/2; i++) {
        if (n % i == 0) {
            sum += i;
        }
    }
    return sum;
}