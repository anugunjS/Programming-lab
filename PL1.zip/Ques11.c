#include <stdio.h>
#include <limits.h>

void searchL(int arr[],int n);


int main() {
    int n=0;
    printf("Enter size: ");
    scanf("%d",&n);
    int arr[n],i;

    printf("Inupt:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    searchL(arr, n);
     return 0;
}

void searchL(int arr[],int n)
{
    int f,s,i;
    if (n<2)
    {
        printf("Invalid\n");
        return;
    }
    f=s=INT_MIN;
    for (i=0;i<n; i++)
    {
        if (arr[i]>f)
        {
            s=f;
            f=arr[i];
        }
        else if (arr[i]>s && arr[i]!=f)
        {
            s = arr[i];
        }
    }
        printf("largest : %d,second-largest: %d\n",f,s);
}
