#include <stdio.h>
#include <stdbool.h>

bool arePer(int a, int b);
bool isPrime(int num);

int main() {
    int start=1000;
    int end =9999;

    for (int a = start; a <= end; ++a)
        {
        if (isPrime(a))
        {
            for (int d = 1; d <= (end - a) / 2; ++d)
             {
                int b = a + d;
                int c = b + d;
                if (b <= end && c <= end && isPrime(b) && isPrime(c) && arePer(a, b) && arePer(a, c))
                {
                    printf("Found sequence: %d, %d, %d\n", a, b, c);
                    printf("Concatenated 12-digit number: %d%d%d\n", a, b, c);
                }
            }
        }
    }

    return 0;
}

bool arePer(int a, int b)
{
    int count[10] = {0};
    while (a > 0)
    {
        count[a % 10]++;
        a /= 10;
    }
    while (b > 0)
    {
        count[b % 10]--;
        b /= 10;
    }
    for (int i = 0; i < 10; ++i)
    {
        if (count[i] != 0)
            return false;
    }
    return true;
}

bool isPrime(int num)
{
    if (num <= 1)
        return false;
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0)
            return false;
    }
    return true;
}
