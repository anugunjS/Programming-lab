#include <stdio.h>
#include <stdbool.h>

#define N 10

void check(int *per, int size, int k);

int main()
{
    int per[N];
    int k =1000000;

    check(per, N, k);

    printf("The millionth lexicographic permutation of digits 0 through 9 is:\n");
    for (int i = 0; i < N; i++) {
        printf("%d", per[i]);
    }
    printf("\n");

    return 0;
}

void check(int per[], int size, int k)
{
    int fac[N];
    bool used[N] = {false};
    int i, j;

    fac[0] = 1;
    for (i = 1; i < N; i++) {
        fac[i] = fac[i - 1] * i;
    }
    k--;
    for (i = 0; i < N; i++)
    {
        int index = k / fac[N - i - 1];
        k %= fac[N - i - 1];

        for (j = 0; j < N; j++)
        {
            if (!used[j]) {
                if (index == 0) 
                {
                    per[i] = j;
                    used[j] = true;
                    break;
                }
                index--;
            }
        }
    }
}