#include <stdio.h>

 void checkNum(int n);
 
int main() {
    int n;
    printf("Enter an integer: ");
    scanf("%d", &n);
    checkNum(n);
    return 0;
}

void checkNum(int n){
    int sum=0,i;
     for ( i = 1; i <= n/2; i++) {
        if (n % i == 0) {
            sum += i;
        }
    }

    if (sum == n) {
        printf("%d is a perfect number.\n", n);
       }
     else if (sum>n) {
        printf("%d is a abundant number.\n", n);
        }
      else {
        printf("%d is a deficient number.\n", n);
      }
}