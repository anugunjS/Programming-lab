#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 1000

void check(int arr[], int n);


int main()
{
    int n,i;
    printf("Enter size: ");
    scanf("%d",&n);
    int arr[n];
    printf("Input:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    check(arr,n);
     return 0;
}

void check(int arr[], int n)
{
    int hash[MAX]={0};
    int maxFreq = 0;
    int ele=-1,i;
    for (i=0;i<n; i++)
    {
        hash[arr[i]]++;
        if (hash[arr[i]] > maxFreq)
        {
            maxFreq = hash[arr[i]];
            ele = arr[i];
        }
    }
    printf("Element:%d Frequency:%d\n",ele,maxFreq);
}
