#include <stdio.h>
#include <math.h>


typedef struct {
    double x;
    double y;
} Coordi;


int checkCo(Coordi a,Coordi b,Coordi c);
void checkTri(Coordi a,Coordi b,Coordi c);
double dis(Coordi a,Coordi b);



int main()
{
    Coordi p1, p2, p3;
    printf("Enter coordinates of point 1(x,y):\n");
    scanf("%lf %lf",&p1.x,&p1.y);
    printf("Enter coordinates of point 2 (x,y):\n");
    scanf("%lf %lf",&p2.x,&p2.y);
    printf("Enter coordinates of point 3 (x,y)):\n");
    scanf("%lf %lf",&p3.x,&p3.y);

    if (checkCo(p1,p2,p3))
    {
        printf("The points are collinear.\n");
        return 0;
    }
    checkTri(p1,p2,p3);
    return 0;
}




void checkTri(Coordi p1,Coordi p2,Coordi p3)
{
    double d1 =dis(p1,p2);
    double d2 =dis(p2,p3);
    double d3 =dis(p3,p1);

    if (d1==d2 && d2==d3)
    {
        printf("Equilateral triangle.\n");
    }
    else if (d1==d2||d2==d3||d1==d3)
    {
        printf("Isosceles triangle.\n");
    }
    else
    {
        printf("Scalene triangle.\n");
    }
}




double dis(Coordi a, Coordi b)
{
    return sqrt(pow(b.x-a.x,2)+pow(b.y-a.y,2));
}


int checkCo(Coordi a,Coordi b,Coordi c)
{
    return (a.x * (b.y-c.y)+b.x * (c.y-a.y)+c.x * (a.y-b.y))==0;
}
