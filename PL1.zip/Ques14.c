#include <stdio.h>
#include <stdlib.h>

int compare(const void *a, const void *b);
void rearrangeArray(int arr[], int n);

int main()
{
    int n;
    printf("Enter size: ");
    scanf("%d", &n);

    if (n <= 0)
    {
        printf("The number of integers must be positive.\n");
        return 1;
    }
    int *arr = (int*)malloc(n * sizeof(int));
    if (arr == NULL)
    {
        printf("Memory allocation failed.\n");
        return 1;
    }
    printf("Enter the %d distinct integers:\n", n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    rearrangeArray(arr, n);
    free(arr);
    return 0;
}

void rearrangeArray(int arr[], int n)
{
    qsort(arr, n, sizeof(int), compare);

    for (int i = 0; i < n; i++)
    {
        printf("%d", arr[i]);
        if (i < n - 1)
        {
            printf(",");
        }
    }
    printf("\n");
}


int compare(const void *a, const void *b)
{
    return (*(int*)b -*(int*)a);
}
