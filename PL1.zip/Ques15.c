#include <stdio.h>
#include <math.h>

#define DIVISOR_LIMIT 500

int divisors(int num);
int triangularNum(int limit);


int main()
{
    int limit = DIVISOR_LIMIT;
    int res = triangularNum(limit);

    printf("The first triangular number with more than %d divisors is: %d\n", limit, res);

    return 0;
}

int divisors(int num)
{
    int count = 0;
    int sq = (int)sqrt(num);

    for (int i = 1;i<= sq;i++)
    {
        if (num % i == 0)
        {
            if (i == num / i)
                count++;
            else
                count += 2;
        }
    }

    return count;
}

int triangularNum(int limit)
{
    int index=1;
    long int tn;
    int div;

    while (1)
    {
        tn = index*(index + 1)/ 2;
        div = divisors(tn);

        if (div > limit)
        {
            return tn;
        }

        index++;
    }
}
