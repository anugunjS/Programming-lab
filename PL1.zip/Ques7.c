#include <stdio.h>

int checkHar(int n);

int main()
{
    int n;
    printf("Input: ");
    scanf("%d",&n);
    if (checkHar(n)) {
        printf("%d is a Harshad number.\n",n);
    } else {
        printf("%d is not a Harshad number.\n",n);
    }
    return 0;
}


int checkHar(int n)
  {
    int sum =0,temp=n;
    while (temp > 0) {
        sum +=temp%10;
        temp/=10;
    }

    return (n%sum == 0);
}
