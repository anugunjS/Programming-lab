#include <stdio.h>

int com(int n, int r);
int per(int n, int r);
int fac(int n);

int main() {
    int n,r;
    printf("Enter n: ");
    scanf("%d",&n);
    printf("Enter r: ");
    scanf("%d",&r);
    printf("Permutations  = %d\n", per(n, r));
    printf("Combinations  = %d\n", com(n, r));

    return 0;
}



int com(int n, int r)
{
    return fac(n) / (fac(r) * fac(n - r));
}


int per(int n, int r)
 {
    return fac(n) / fac(n - r);
}

int fac(int n)
 {
    if (n == 0)
        {
        return 1;
    }
    else
     {
        return n * fac(n-1);
    }
}
