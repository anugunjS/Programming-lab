#include <stdio.h>
#include <string.h>

void encrypt(char *str);

int main()
{
    char str[100];
    printf("Input: ");
    fgets(str,sizeof(str),stdin);//scanf("%s", str);
    encrypt(str);
    printf("Output: %s ",str);
    return 0;
}


void encrypt(char *str)
 {
    int i;
    for (i = 0;i< strlen(str); i++)
    {
        if (str[i] =='a')
            {
            str[i] ='b';
            }
       else if (str[i] =='A')
          {
            str[i] ='B';
          }
    }
}
