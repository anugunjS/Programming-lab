#include <stdio.h>
#include <math.h>

void sum(double x,int n);

int main()
{
    double x;
    int n;
    printf("Enter the value of x (-1 < x <= 1): ");
    scanf("%lf",&x);
    printf("Enter the value of n (n > 100): ");
    scanf("%d",&n);
    sum(x,n);
    return 0;
}

void sum(double x,int n)
{
    if(n<=100 || n < -1 || n > 1)
    {
        printf("Invalid");
        return;
    }
   double sum=0;
   int i;
   for (i =1;i<= n;i++)
    {
        sum += pow(-1,i+1)*pow(x,i)/i;
    }

    printf("The sum of the given series is: %lf", sum);
}
