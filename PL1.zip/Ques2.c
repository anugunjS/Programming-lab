#include <stdio.h>
#include<math.h>
void checkAN(int n);

int main() {
    int n;
    printf("Input: ");
    scanf("%d", &n);
    checkAN(n);
    return 0;
}

void checkAN(int n){
    int num, r, sum= 0;
      num = n;
    while (num != 0)
    {
        r= num % 10;
       sum += pow(r,3);
        num/= 10;
    }
     if (sum == n) {
        printf("%d is an Armstrong number.\n", n);
    } else {
        printf("%d is not an Armstrong number.\n", n);
    }

}
