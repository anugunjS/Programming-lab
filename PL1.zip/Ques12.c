
#include <stdio.h>
#include <stdlib.h>

#define MAX 1000

void printS(int *set,int size);
int unionAB(int A[],int n,int B[],int m,int res[]);
int interAB(int A[],int n,int B[],int m,int res[]);
int setdiffAB(int A[],int n,int B[],int m,int res[]);
int symdiffAB(int A[],int n,int B[],int m,int res[]);


int main()
 {
    int n,i,m,f1;
    int res[MAX];
    printf("Enter size of the first set:\n");
    scanf("%d",&n);
    int A[n];
    printf("Enter %d integers:\n",n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&A[i]);
    }

    printf("Enter size of the second set:\n");
    scanf("%d",&m);
    int B[m];
    printf("Enter %d integers:\n",m);
    for(i=0;i<m;i++)
    {
        scanf("%d",&B[i]);
    }
    f1=unionAB(A,n,B,m,res);
    printf("Union: ");
    printS(res,f1);
    f1=interAB(A,n,B,m,res);
    printf("Intersection: ");
    printS(res,f1);
    f1=setdiffAB(A,n,B,m,res);
    printf("A-B: ");
    printS(res,f1);
    f1=setdiffAB(B,m,A,n,res);
    printf("B-A: ");
    printS(res,f1);
    f1=symdiffAB(A,n,B,m,res);
    printf("Symmetric difference: ");
    printS(res,f1);

}

int unionAB(int A[],int n,int B[],int m,int res[])
{
    int i,j,k=0;
    int flag=1;
    for(i=0;i<n;i++)
    {
        res[k]=A[i];
        k++;
    }
    for(i=0;i<m;i++)
    {
         flag=1;
        for(j=0;j<n;j++)
        {
            if(res[j]==B[i])
            {
               flag=0;
            }
        }
        if(flag)
        {
            res[k]=B[i];
            k++;
        }

    }
    return k;

}

int interAB(int A[],int n,int B[],int m,int res[])
{
    int i,j,k=0;
    int flag=1;
    for(i=0;i<m;i++)
    {
         flag=0;
        for(j=0;j<n;j++)
        {
            if(A[j]==B[i])
            {
               flag=1;
            }
        }
        if(flag)
        {
            res[k]=B[i];
            k++;
        }

    }
    return k;
}

int setdiffAB(int A[],int n,int B[],int m, int res[])
{
    int i,j,k=0;
    int flag=1;
    for(i=0;i<m;i++)
    {
         flag=1;
        for(j=0;j<n;j++)
        {
            if(A[i]==B[j])
            {
               flag=0;
            }
        }
        if(flag)
        {
            res[k]=A[i];
            k++;
        }

    }
    return k;

}

int symdiffAB(int A[],int n,int B[],int m,int res[])
{
    int aUb[MAX],a;
    int aIb[MAX],b;
    int c;
    a=setdiffAB(A,n,B,m,aUb);
    b=setdiffAB(B,m,A,n,aIb);
    c=unionAB(aUb,a,aIb,b,res);
    return c;

}

void printS(int *set,int size)
{
    for(int i=0;i<size;i++)
    {
    printf("%d ",set[i]);
    }
    printf("\n");
}
