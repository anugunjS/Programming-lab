#include <stdio.h>

int isCoPrime(int i,int j);



int main()
{
    int i,j;
    printf("Enter two integer values: \n");
    scanf("%d %d",&i,&j);
   if( isCoPrime(i,j))
       printf("Given numbers are Coprime.");
  else
      printf("Given numbers are not Coprime");
     return 0;
     }




int isCoPrime(int i, int j)
{
    if(i<=0 || j<=0){
       printf("invalid inputs\n");
       return -1;
    }
    if(i%j==1)
        return 1;
    if(i%j==0)
        return 0;
    isCoPrime(j,i%j);
   
}