#include <stdio.h>
#include <string.h>
 #define MAX 250

int minOp(char* s, char* t);
int min(int a, int b, int c);

int main() 
{
    char s[MAX];
    printf("String1: ");
    fgets(s,MAX,stdin);
    char t[MAX];
    printf("Strind2: ");
    fgets(t,MAX,stdin);

    int result = minOp(s, t);
    printf("Minimum number of operations required: %d\n", result);

    return 0;
}

int minOp(char* s, char* t)
{
    int m = strlen(s);
    int n = strlen(t);
    int dp[m + 1][n + 1];

    for (int i = 0; i <= m; ++i) 
    {
        for (int j = 0; j <= n; ++j)
        {
            if (i == 0)
                dp[i][j] = j; 
            else if (j == 0)
                dp[i][j] = i; 
            else if (s[i - 1] == t[j - 1])
                dp[i][j] = dp[i - 1][j - 1]; 
            else
                dp[i][j] = 1 + min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]); 
        }
    }
    return dp[m][n];
}

int min(int a, int b, int c) 
{
    return a<b?(a<c?a:c):(b<c?b:c);
}