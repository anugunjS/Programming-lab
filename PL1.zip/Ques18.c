#include <stdio.h>
#include <string.h>

#define MAX 5000
void count( char *name, char *keyword);

int main()
{
    char name[100], keyword[25];

    printf("Enter the filename: ");
    scanf("%s", name);
    printf("Enter the keyword: ");
    scanf("%s", keyword);
    count(name,keyword);
    return 0;
}

void count( char *name, char *keyword)
{
    char line[MAX];
    int count=0;
    FILE *fp;
    fp = fopen(name, "r");
    if (fp == NULL)
    {
        printf("Could not open file %s\n", name);
        return;
    }

    while (fgets(line, sizeof(line), fp))
    {
        char *ptr = line;
        while ((ptr=strstr(ptr, keyword)) != NULL)
        {
            count++;
            ptr += strlen(keyword);
        }
    }

    fclose(fp);
    printf("%d", count);
}
